<?php
namespace App\Forms\Article;

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Forms\Element\TextArea;
use Phalcon\Forms\Element\Date;
use Phalcon\Forms\Element\Submit;
use Phalcon\Forms\Element\Button;
// Validation
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\StringLength;
use Phalcon\Validation\Validator\Email;

class CreateArticleForm extends Form
{
    public function initialize($entity = null, $options = [])
    {
        if (isset($options["edit"])) {
            $id = new Hidden('eid', [
                "required" => true,
            ]);

            $this->add($id);
        }

        /**
         * Title
         */
        $title = new Text('title', [
            "class" => "form-control",
            // "required" => true,
            "placeholder" => "Name of the article"
        ]);

        // form email field validation
        $title->addValidators([
            new PresenceOf(['message' => 'The article title is required']),
        ]);

        /**
         * Summary
         */
        $summary = new TextArea('summary', [
            "class" => "form-control",
            // "required" => true,
            "placeholder" => "Summary of the article",
            "rows" => "5"
        ]);

        // form summary field validation
        $summary->addValidators([
            new PresenceOf(['message' => 'The article summary is required']),
        ]);

        /**
         * Content
         */
        $content = new TextArea('content', [
            "class" => "form-control",
            // "required" => true,
            "placeholder" => "Content of the article",
            "rows" => "15"
        ]);

        // form content field validation
        $content->addValidators([
            new PresenceOf(['message' => 'The article content is required']),
            new StringLength(['min' => 10, 'message' => 'Too short. Minimum of 10 characters']),
        ]);

        /**
         * Publication Date
         */
        $date = new Date('publicationDate', [
            "class" => "form-control",
            // "required" => true,
            "placeholder" => "Content of the article"
        ]);

        // form date field validation
        $date->addValidators([
            new PresenceOf(['message' => 'The article date is required']),
        ]);


        /**
         * Save Changes Button
         */
        $submit = new Submit('submit', [
            "value" => "Save Changes",
            "class" => "btn btn-primary",
        ]);

        // echo "<input type='button' value='Cancel' onclick='history.back();' />";
        // echo "<div>
        //         <a href='/users/confirmed'>Cancel</a> 
        //         <a href='/users/index'>Cancel</a>
        //     </div>";

        // $cancel = new Button('cancel', [
        //     "value" => "Cancel",
        //     "class" => "btn btn-primary",
        // ]);
        
        $this->add($title);
        $this->add($summary);
        $this->add($content);
        $this->add($date);
        $this->add($submit);
        // $this->add($cancel);
    }
}