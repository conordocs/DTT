<?php

use Phalcon\Http\Request;
use App\Forms\Article\CreateArticleForm;
use Phalcon\Db\Column;

class ArticleController extends ControllerBase
{
    public $createArticleForm;
    public $articleModel;

    public function initialize()
        {
            # check user islogin
            $this->authorized();
            $this->createArticleForm = new CreateArticleForm();
            $this->articleModel = new Articles();
            
        }

    public function createAction()
        {
            $this->tag->setTitle('DTT :: Add Article');
            // Add new Article form
            $this->view->form = new CreateArticleForm();
        }

    public function createSubmitAction()
        {
            // check request
            if (!$this->request->isPost()) {
                return $this->response->redirect('user/login');
            }

            // Validate CSRF token
            // if (!$this->security->checkToken()) {
            //     $this->flashSession->error("Invalid Token");
            //     return $this->response->redirect('article/create');
            // }

            # article form with model
            $this->createArticleForm->bind($_POST, $this->articleModel);
            # check form validation
            if(!$this->createArticleForm->isValid()) {
                foreach($this->createArticleForm->getMessages() as $message) {
                    $this->flashSession->error($message);
                    $this->dispatcher->forward([
                        'controller' => $this->router->getControllerName(),
                        'action' => 'create',

                    ]);
                    return;
                    
                }
            }

            if(!$this->articleModel->save()) {
                foreach($this->articleModel->getMessages() as $m) {
                    $this->flashSession->error($m);
                    $this->dispatcher->forward([
                        'controller' => $this->router->getControllerName(),
                        'action' => 'create',
                    ]);
                }
            }

            $this->flashSession->success('Article has been successfully saved');
            return $this->response->redirect('article/manage');

            $this->view->disable();
        }


        /**
         * Manage articles
         */
        public function manageAction() 
        {
            $this->tag->setTitle('DTT :: Manage');

            // fetching all articles
            // $articles = Articles::find("title = 'Nederlandse simkaartfabrikant Gemalto vermoedt hack door NSA'");
            $articles = Articles::find(
                [
                    // "title = 'Nederlandse simkaartfabrikant Gemalto vermoedt hack door NSA'",
                    'order' => 'publicationDate	ASC',
                ]
            );
                echo "<h2>All Articles</h2>";
            foreach ($articles as $article) {
                // echo "<h2>All Articles</h2>";
                echo $article->publicationDate, "\n";
                echo $article->title;
                echo "<br/>";
                
            }

            $this->view->articlesData = $articles;

            // $this->view->disable();
        }
        
        /**
         * Edit Article
         */
        public function editAction($articleId = null)
        {
            // Set Page Title
            $this->tag->setTitle('DTT :: Edit Article');

            // Check article id not empty
            if (!empty($articleId) AND $articleId != null)
            {
                // Check Post Request
                if($this->request->isPost())
                {
                    # bind user type data
                    $this->createArticleForm->bind($this->request->getPost(), $this->articleModel);
                    $this->view->form = new CreateArticleForm($this->articleModel, [
                        "edit" => true
                    ]);
                    
                } else {
                    // Fetch User Article
                    $article = Articles::findFirst($articleId);
                    
                    if (!$article) {
                        $this->flashSession->error('Article was not found');
                        return $this->response->redirect('article/create');
                    }

                    // Send Article Data in Article Form
                    $this->view->form = new CreateArticleForm($article, [
                        "edit" => true
                    ]);
                }

            } else {
                return $this->response->redirect('article/manage');
            }
        }

        /**
         * Edit Article Action Submit
         */
        public function editSubmitAction()
        {
            // check post request
            if (!$this->request->isPost()) {
                return $this->response->redirect('article/manage');
            }

            // Check Article is Valid
            $article = Articles::findFirst($articleId);

            if (!$article) {
                $this->flashSession->error('Article was not found');
                return $this->response->redirect('article/create');
            }

            # Check Form Validation
            if (!$this->createArticleForm->isValid($this->request->getPost(), $article)) {
                foreach ($this->createArticleForm->getMessages() as $message) {
                    $this->flashSession->error($message);
                    return $this->dispatcher->forward([
                        'controller' => $this->router->getControllerName(),
                        'action'     => 'edit',
                        'params' => [$articleId]
                    ]);
                }
            }

            // article id set
            $this->articleModel->setId($articleId);
            

            if ($this->articleModel->save($_POST) === false) {
                foreach ($this->articleModel->getMessages() as $m) {
                    $this->flashSession->error($m);
                }

                return $this->dispatcher->forward([
                    'controller' => $this->router->getControllerName(),
                    'action'     => 'edit',
                ]);
            }

            // set new article data

            

            // article id set
            // $this->articleModel->setId($articleId);

            if ($this->articleModel->save($_POST) === false) {
                foreach ($this->articleModel->getMessages() as $m) {
                    $this->flashSession->error($m);
                }
                return $this->dispatcher->forward([
                    'controller' => $this->router->getControllerName(),
                    'action'     => 'edit',
                ]);
            }

            // Clear Article Form
            $this->createArticleForm->clear();

            $this->flashSession->success('Article was updated successfully.');
            return $this->response->redirect('article/manage');

            $this->view->disable();
        }

        /**
         * Delete Article
         */
        public function deleteAction($articleId)
        {
            $id = (int) $articleId;
            if($id > 0 AND !empty($id)) 
            {
                $article = Articles::find($articleId);
                
                if (!$article) {
                    $this->flashSession->error('Article was not found');
                    return $this->response->redirect('article/manage');
                }

                if(!$article->delete()) 
                {
                    foreach ($article->getMessages() as $msg) {
                        $this->flashSession->error((string) $msg);
                    }
                    return $this->response->redirect('article/manage');
                } else {
                    $this->flashSession->success("Article has been deleted successfully");
                    return $this->response->redirect('article/manage');
                }

            } else {
                $this->flashSession->error("Article ID is invalid");
                return $this->response->redirect('article/manage');
            }

            $this->view->disable();
        }

}

