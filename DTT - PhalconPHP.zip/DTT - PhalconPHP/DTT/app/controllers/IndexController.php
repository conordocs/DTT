<?php

use Phalcon\Http\Request;
use App\Forms\Article\CreateArticleForm;
use Phalcon\Db\Column;

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        // Add some local CSS resources
        $this->assets->addCss('css/styles.css');
        
        $this->tag->setTitle('DTT :: Home');

        // fetching all articles
        $articles = Articles::find(
            [
                'order' => 'publicationDate	ASC',
            ]
        );
            echo "<h2>All Articles</h2>";
        foreach ($articles as $article) {
            echo $article->publicationDate, "\n";
            echo $article->title;
            echo "<br/>";
            
        }

        $this->view->articlesData = $articles;

        // $this->view->disable();
    }

    public function show404Action()
    {

    }

    public function show503Action()
    {

    }

    public function viewAction($articleId) {

        // Add some local CSS resources
        $this->assets->addCss('public/css/styles.css');

        $this->tag->setTitle('DTT :: View');

        // fetching all articles
        $articles = Articles::find($articleId);

        foreach ($articles as $article) {
        echo $article->publicationDate, "\n";
        echo $article->title;
        echo $article->content;
        echo "<br/>";
            
        }

        $this->view->articlesData = $articles;

        // $this->view->disable();
    }

    public function archiveAction()
    {
        $this->tag->setTitle('DTT :: Archive');

        // fetching all articles
        $articles = Articles::find(
            [
                'order' => 'publicationDate	ASC',
            ]
        );
            echo "<h2>All Articles</h2>";
            
            foreach ($articles as $article) {
                echo $article->publicationDate, "\n";
                echo $article->title;
                echo "<br/>";
            
        }

        $this->view->articlesData = $articles;

        // $this->view->disable();
    }
}