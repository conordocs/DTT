-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2019 at 02:08 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dtt`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `summary` text NOT NULL,
  `content` text NOT NULL,
  `publicationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `summary`, `content`, `publicationDate`) VALUES
(1, 'Nederlandse simkaartfabrikant Gemalto vermoedt hack door NSA', 'De Nederlands-Franse simkaartfabrikant Gemalto heeft \"gegronde redenen\" om aan te nemen dat Amerikaanse en Britse veiligheidsdiensten het bedrijf hebben gehackt.', 'De aanvallen van de NSA en GCHQ zouden in 2010 en 2011 hebben plaatsgevonden en hoewel Gemalto zegt regelmatig slachtoffer te zijn van cyberaanvallen, heeft het activiteiten in die periode gevonden die overeen lijken te komen met een hack door de veiligheidsdiensten.\r\n\r\nIn 2010 werd het Franse interne netwerk van Gemalto aangevallen en later dat jaar werden er e-mails naar medewerkers onderschept met malware. Tegelijkertijd werden verschillende pogingen gedaan om de pc\'s van Gemalto-medewerkers te kraken die regelmatig contact hadden met klanten van het bedrijf.\r\n\r\nDe organisatie of personen achter de aanvallen werden nooit gevonden, maar Gemalto heeft nu een sterk vermoeden dat de NSA en GCHQ er achter zaten.\r\n\r\nDe delen van het netwerk die gehackt zijn, bevatten echter geen encryptiesleutels van simkaarten en er zijn geen inbraken gevonden op het deel van het netwerk waar die wel zijn opgeslagen. Dat gedeelte is veel moeilijker te penetreren.', '2015-02-24'),
(2, 'Veltman met Ajax naar Polen voor return in Europa League', 'Joël Veltman reist woensdagmiddag met de selectie van Ajax naar Polen voor de uitwedstrijd in de Europa League tegen Legia Warschau. De verdediger is voldoende hersteld van een hamstringblessure.', 'Veltman liep de blessure in de winterstop op tijdens een oefenwedstrijd tegen Schalke 04. Hij maakte anderhalve week geleden zijn rentree tegen FC Twente, maar moest snel weer afhaken.\r\n\r\nTrainer Frank de Boer heeft ook Jairo Riedewald opgenomen in de selectie. Richairo Zivkovic, die zondag tegen Willem II inviel, blijft achter in Amsterdam.\r\n\r\nIn totaal neemt de De Boer negentien spelers mee naar de hoofdstad van Polen, waarvan er nog één zal moeten afvallen.\r\n\r\nAjax verdedigt donderdagavond een voorsprong van 1-0 op Legia Warschau.', '2015-02-25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `active`) VALUES
(39, 'Admin', 'cdoherty101@qub.ac.uk', '$2y$08$VXdUc09ac3lsdXZjeXJhVOJBZAXnu.d3XjRUyN/JwfYwZY504m2ey', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
